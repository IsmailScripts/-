<?php
//addserver_page.php
include("data_class.php");



$bookname=$_POST['bookname'];



$obj=new data();
$obj->setconnection();
$obj->mydelbook($bookname);
