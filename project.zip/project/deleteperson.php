<?php
//addserver_page.php
include("data_class.php");



$personname=$_POST['personname'];



$obj=new data();
$obj->setconnection();
$obj->mydelperson($personname);
