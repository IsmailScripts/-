CREATE DATABASE IF NOT EXISTS Library;
use Library;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_managment`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS admin;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL primary key,
  `email` varchar(40) NOT NULL,
  `pass` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
desc `admin`;
--
-- --------------------------------------------------------

--
-- Table structure for table `book`
--
DROP TABLE IF EXISTS book;

CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `bookpic` varchar(25) NOT NULL,
  `bookname` varchar(25) NOT NULL,
  `bookdetail` varchar(110) NOT NULL,
  `bookauthor` varchar(25) NOT NULL,
  `bookpub` varchar(25) NOT NULL,
  `branch` varchar(110) NOT NULL,
  `bookprice` varchar(25) NOT NULL,
  `bookquantity` varchar(25) NOT NULL,
  `bookava` int(11) NOT NULL,
  `bookrent` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
desc book;
--
-- Dumping data for table `book`
--

-- --------------------------------------------------------
--
-- Table structure for table `issuebook`
--
DROP TABLE IF EXISTS issuebook;

CREATE TABLE `issuebook` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `issuename` varchar(25) NOT NULL,
  `issuebook` varchar(25) NOT NULL,
  `issuetype` varchar(25) NOT NULL,
  `issuedays` int(11) NOT NULL,
  `issuedate` varchar(25) NOT NULL,
  `issuereturn` varchar(25) NOT NULL,
  `fine` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
desc issuebook;
--
-- Dumping data for table `issuebook`
--
-- --------------------------------------------------------

--
-- Table structure for table `requestbook`
--
DROP TABLE IF EXISTS requestbook;

CREATE TABLE `requestbook` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `bookid` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `usertype` varchar(25) NOT NULL,
  `bookname` varchar(25) NOT NULL,
  `issuedays` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
desc requestbook;
-- --------------------------------------------------------

--
-- Table structure for table `userdata`
--
DROP TABLE IF EXISTS userdata;

CREATE TABLE `userdata` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `pass` varchar(25) NOT NULL,
  `type` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userdata`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `issuebook`
--
ALTER TABLE `issuebook`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pk_fk` (`userid`);

--
-- Indexes for table `requestbook`
--
ALTER TABLE `requestbook`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pk_fk_book` (`bookid`),
  ADD KEY `pk_fk_users` (`userid`);

--
-- Indexes for table `userdata`
--
ALTER TABLE `userdata`
  ADD PRIMARY KEY (`id`);


-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;

--
-- AUTO_INCREMENT for table `issuebook`
--
ALTER TABLE `issuebook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;

--
-- AUTO_INCREMENT for table `requestbook`
--
ALTER TABLE `requestbook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;

--
-- AUTO_INCREMENT for table `userdata`
--
ALTER TABLE `userdata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;



--
-- Constraints for table `issuebook`
--
ALTER TABLE `issuebook`
  ADD CONSTRAINT `pk_fk` FOREIGN KEY (`userid`) REFERENCES `userdata` (`id`);

--
-- Constraints for table `requestbook`
--
ALTER TABLE `requestbook`
  ADD CONSTRAINT `pk_fk_users` FOREIGN KEY (`userid`) REFERENCES `userdata` (`id`);
COMMIT;

-- group functions
SELECT AVG(bookprice) as 'Average',MAX(bookprice) as 'Max price',MIN(bookprice) as 'Min price'
FROM book;
select * from book;

SELECT COUNT(userid) 
FROM issuebook;

SELECT id,AVG(pass/2) 
FROM `admin` 
GROUP BY id;

SELECT issuebook,issuename,issuedate 
FROM issuebook 
GROUP BY id,userid;

-- joins
SELECT a.id,u.id 
FROM `admin` as a
INNER JOIN userdata as u
ON a.id = u.id;

SELECT book.bookname,book.bookauthor,issuebook.issuetype 
FROM book 
RIGHT JOIN issuebook 
ON book.id = issuebook.id;


-- select 
SELECT id AS "BOOK ID",bookpub AS "PUBLISHER NAME",bookdetail "DESCRIPTION" 
FROM book;
SELECT * FROM book; 
SELECT * FROM `admin`;
SELECT * FROM issuebook;
SELECT * FROM requestbook;
SELECT * FROM userdata;


-- functions
SELECT bookname,bookauthor AS AUTHOR 
FROM book 
WHERE LOWER(bookname) 
LIKE "%s%";

SELECT userid,CONCAT(issuebook,issuetype) 
FROM issuebook 
WHERE id 
BETWEEN 6 AND 11;
select * from book;
-- subqueries
SELECT * 
FROM book 
WHERE bookava  
IN (
SELECT bookava 
FROM book 
WHERE bookprice > 500
);

SELECT issuename,issuebook,issuedate 
FROM issuebook 
GROUP BY id 
HAVING id >= ( 
SELECT MIN(id) 
FROM issuebook 
WHERE id> 6
);

-- views
CREATE VIEW BookDetails 
AS 
SELECT bookname,bookdetail,bookprice,bookauthor as Author 
FROM book 
WHERE id=6;
select * from BookDetails;
drop view BookDetails;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
